﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Data.SQLite;
//using System.Globalization;

namespace GoblinGenerator
{
    class Goblin
    {

        public int id;
        public string name;

        public string hair;
        public string ear;
        public string hairColor;
        public string eyeColor;
        public string skinColor;

        public string bodyWear;
        public string headWear;
        public string legWear;
    }

    class GoblinID
    {

        public int id;
        public string nameId;

        public int hairId;
        public int earId;
        public int hairColorId;
        public int eyeColorId;
        public int skinColorId;

        public int bodyWearId;
        public int headWearId;
        public int legWearId;
    }

    class Data
    {
        public int goblings;
        public int namesLenght;

        public int hairsLenght;
        public int earsLenght;

        public int hairColorsLenght;
        public int eyeColorsLenght;
        public int skinColorsLenght;

        public int bodyWearsLenght;
        public int headWearsLenght;
        public int legWearsLenght;
    }






    class Program
    {

        public static List<GoblinID> FindGoblingsId(SQLiteConnection myConnection)
        {
            int i = 0;

            List<GoblinID> goblinsId = new List<GoblinID>();


            var byGoblin = "SELECT * FROM Goblin";
            SQLiteCommand goblin = new SQLiteCommand(byGoblin, myConnection);
            var oleg = goblin;


            //Etsii ID Arvot kaikille goblineille
            using (var reader = oleg.ExecuteReader())
            {
                while (reader.Read())
                {

                    //Console.WriteLine("!");


                    goblinsId.Insert(i, new GoblinID
                    {

                        id = reader.GetInt32(0),

                        nameId = reader.GetString(1),

                        hairId = reader.GetInt32(2),
                        earId = reader.GetInt32(3),

                        headWearId = reader.GetInt32(4),
                        bodyWearId = reader.GetInt32(5),
                        hairColorId = reader.GetInt32(6),
                        skinColorId = reader.GetInt32(7),
                        eyeColorId = reader.GetInt32(8),
                        legWearId = reader.GetInt32(9)



                    });


                    i++;

                }

            }
            return goblinsId;
        }

        public static List<Goblin> FindGoblings(SQLiteConnection myConnection, List<GoblinID> goblinsId)
        {
            int j = 0;

            List<Goblin> goblins = new List<Goblin>();


            //Wind words for saved ids
            foreach (GoblinID gobo in goblinsId)
            {

                //Starting falues for all parts
                string nameString = "XXX";
                string hairString = "XXX";
                string earString = "XXX";
                string eyeColorString = "XXX";
                string hairColorString = "XXX";
                string skinColorString = "XXX";

                string bodyWearString = "XXX";
                string headWearString = "XXX";
                string legWearString = "XXX";


                //GEt string from tables
                nameString = goblinsId[j].nameId;

                hairString = GetString("SELECT * FROM Hair WHERE ID = ", myConnection, goblinsId[j].hairId);

                earString = GetString("SELECT * FROM Ears WHERE ID = ", myConnection, goblinsId[j].earId);

                eyeColorString = GetString("SELECT * FROM EyeColor WHERE ID = ", myConnection, goblinsId[j].eyeColorId);

                hairColorString = GetString("SELECT * FROM HairColor WHERE ID = ", myConnection, goblinsId[j].hairColorId);

                skinColorString = GetString("SELECT * FROM SkinColor WHERE ID = ", myConnection, goblinsId[j].skinColorId);


                bodyWearString = GetString("SELECT * FROM BodyWear WHERE ID = ", myConnection, goblinsId[j].bodyWearId);

                headWearString = GetString("SELECT * FROM HeadWear WHERE ID = ", myConnection, goblinsId[j].headWearId);

                legWearString = GetString("SELECT * FROM LegWear WHERE ID = ", myConnection, goblinsId[j].legWearId);




                //Insert values to gobling list
                goblins.Insert(j, new Goblin
                {

                    id = (j + 1),

                    name = nameString,

                    hair = hairString,
                    ear = earString,
                    eyeColor = eyeColorString,
                    hairColor = hairColorString,
                    skinColor = skinColorString,

                    bodyWear = bodyWearString,
                    headWear = headWearString,
                    legWear = legWearString
                });
                j++;
            }
            return goblins;


        }

        static void WriteText(string query, SQLiteConnection connection)
        {

            SQLiteCommand myCommand = new SQLiteCommand(query, connection);
            SQLiteDataReader result = myCommand.ExecuteReader();


            if (result.HasRows)
            {
                while (result.Read())
                {
                    int num = result.GetInt32(0);
                    string name = result.GetString(1);
                    Console.WriteLine(num + " : " + name);

                }
            }
        }

        public static string GetString(string query, SQLiteConnection myConnection, int intiger)
        {
            var byquery = query + intiger;
            string quest = "0";
            SQLiteCommand newquery = new SQLiteCommand(byquery, myConnection);

            //Get string from table
            using (var queryReader = newquery.ExecuteReader())
            {
                while (queryReader.Read())
                {
                    quest = queryReader.GetString(1);

                }
            }
            return quest;
        }

        public static int GetLenght(string query, SQLiteConnection myConnection)
        {

            int lenght = 0;
            SQLiteCommand newquery = new SQLiteCommand(query, myConnection);

            using (var querytReader = newquery.ExecuteReader())
            {
                while (querytReader.Read())
                {
                    lenght = querytReader.GetInt32(0);
                }
            }
            return lenght;
        }

        public static Data GetAllLenght(SQLiteConnection myConnection)
        {
            Data data = new Data();


            //Get max lenght of all tables
            data.goblings = GetLenght("SELECT MAX(ID) AS LID FROM Goblin; ", myConnection);
            data.namesLenght = GetLenght("SELECT MAX(ID) AS LID FROM Name; ", myConnection);

            data.hairsLenght = GetLenght("SELECT MAX(ID) AS LID FROM Hair; ", myConnection);
            data.earsLenght = GetLenght("SELECT MAX(ID) AS LID FROM Ears; ", myConnection);

            data.hairColorsLenght = GetLenght("SELECT MAX(ID) AS LID FROM HairColor; ", myConnection);
            data.eyeColorsLenght = GetLenght("SELECT MAX(ID) AS LID FROM EyeColor; ", myConnection);
            data.skinColorsLenght = GetLenght("SELECT MAX(ID) AS LID FROM SkinColor; ", myConnection);

            data.bodyWearsLenght = GetLenght("SELECT MAX(ID) AS LID FROM BodyWear; ", myConnection);
            data.headWearsLenght = GetLenght("SELECT MAX(ID) AS LID FROM HeadWear; ", myConnection);
            data.legWearsLenght = GetLenght("SELECT MAX(ID) AS LID FROM LegWear; ", myConnection);
            return data;
        }

        public static int GetNumber(int data, SQLiteConnection myConnection, string question, string quary, int it, int _out)
        {
            bool hood = false;


            int returnInput;

            int input = 0;
            string word;


            while (!hood)
            {
                Console.Clear();

                Console.WriteLine("CREATION: (" + it + "/" + _out + ")");
                Console.WriteLine(question);

                WriteText(quary, myConnection);

                word = Console.ReadLine();
                Int32.TryParse(word, out input);


                if (input <= data && input >= 0)
                {
                    hood = true;
                }
                else
                {
                    Console.Clear();
                }
            }


            returnInput = input;

            return returnInput;

        }

        public static int GetSmallNumber(int data, SQLiteConnection myConnection)
        {
            bool hood = false;


            int returnInput;

            int input = 0;
            string word;


            while (!hood)
            {
                word = Console.ReadLine();
                Int32.TryParse(word, out input);


                if (input <= data && input > 0)
                {
                    hood = true;
                }
            }


            returnInput = input;

            return returnInput;

        }

        public static void WriteGobling(List<Goblin> goblin, int intiger)
        {
            //BODY 
            Console.WriteLine("Her name is " + goblin[intiger].name + ".");

            Console.WriteLine("Her eyes are " + goblin[intiger].eyeColor + " colored, and her skin is " + goblin[intiger].skinColor + ".");
            Console.WriteLine("Her ears are " + goblin[intiger].ear + " and her hairstyle is " + goblin[intiger].hair + ", colored " + goblin[intiger].hairColor + ".");

            //CLOTHES 
            Console.WriteLine("She wears " + goblin[intiger].legWear + " on her feet and she wears " + goblin[intiger].bodyWear + " as an dress. ");
            Console.WriteLine("She wears " + goblin[intiger].headWear + " on her head. ");
            Console.WriteLine("--------------------------------");
        }

        public static void WriteBasicGoblin(List<Goblin> goblin, int intiger)
        {
            Console.WriteLine("(" + goblin[intiger].id + ") " + goblin[intiger].name);
        }

        static void Main(string[] args)
        {

            //Check if database if found
            if (!File.Exists("Goblin.db")) { Console.WriteLine("Can't find the file!"); }

            //Connnetion 
            SQLiteConnection myConnection = new SQLiteConnection("Data Source=Goblin.db");
            SQLiteConnection myConnection2 = new SQLiteConnection("Data Source=Data.db");
            myConnection.Open();
            myConnection2.Open();

            //List for possible goblings
            List<Goblin> goblins = new List<Goblin>(100);

            //Find goblings and add right words from tables
            goblins = FindGoblings(myConnection, FindGoblingsId(myConnection));

            //Leght of different tables
            Data data = new Data();
            data = GetAllLenght(myConnection);

            //Random for random numbers
            Random r = new Random();

            //Link for quiting the program
            bool link = false;



            while (!link)
            {
                Console.WriteLine("1. Print goblins");
                Console.WriteLine("2. Create New Goblin");
                Console.WriteLine("3. New Random Goblin");
                Console.WriteLine("0. Quit program");

                int key = Convert.ToInt32(Console.ReadLine());

                switch (key)
                {
                    //Print goblins
                    case 1:
                        Console.Clear();

                        bool truest = false;
                        int it = 0;

                        int loadInt;

                        //Write all possible gobling options
                        while (!truest)
                        {
                            Console.Clear();
                            foreach (Goblin gobo in goblins)
                            {
                                WriteBasicGoblin(goblins, it);
                                //WriteGobling(goblins, it);
                                it++;
                            }

                            it = 0;

                            loadInt = GetSmallNumber(data.goblings, myConnection);
                            Console.Clear();
                            WriteGobling(goblins, loadInt - 1);


                            Console.WriteLine("Continue browsing goblings? (y)");
                            string question3;
                            question3 = Console.ReadLine();
                            if (question3 == "y")
                            {
                                truest = true;
                            }

                            Console.Clear();
                        }





                        break;

                    //Crete gobling. 
                    case 2:
                        Console.Clear();

                        bool thruuth = false;

                        string nameString1 = "XXX";
                        string hairString1 = "XXX";
                        string earString1 = "XXX";
                        string eyeColorString1 = "XXX";
                        string hairColorString1 = "XXX";
                        string skinColorString1 = "XXX";

                        string bodyWearString1 = "XXX";
                        string headWearString1 = "XXX";
                        string legWearString1 = "XXX";




                        string name = "0";
                        int numHair = 0;
                        int numEar = 0;

                        int numEyeColor = 0;
                        int numHairColor = 0;
                        int numSkinColor = 0;

                        int numBodyWear = 0;
                        int numHeadWear = 0;
                        int numLegWear = 0;

                        while (!thruuth)
                        {

                            //Name
                            Console.WriteLine("CREATION: (" + 1 + "/" + 9 + ")");
                            Console.WriteLine("Her name is: ");
                            name = Console.ReadLine();

                            numHair = GetNumber(data.hairsLenght, myConnection, "Her hair style is: ", "SELECT * FROM Hair", 2, 9);
                            numEar = GetNumber(data.earsLenght, myConnection, "Her ears are shaped like: ", "SELECT * FROM Ears", 3, 9);
                            numHeadWear = GetNumber(data.headWearsLenght, myConnection, "Her head wear is: ", "SELECT * FROM HeadWear", 4, 9);
                            numHairColor = GetNumber(data.hairColorsLenght, myConnection, "Her hair color is: ", "SELECT * FROM HairColor", 5, 9);
                            numBodyWear = GetNumber(data.bodyWearsLenght, myConnection, "Her body wear is: ", "SELECT * FROM BodyWear", 6, 9);
                            numSkinColor = GetNumber(data.skinColorsLenght, myConnection, "Her skin color is like: ", "SELECT * FROM SkinColor", 7, 9);
                            numEyeColor = GetNumber(data.eyeColorsLenght, myConnection, "Her eyes are: ", "SELECT * FROM EyeColor", 8, 9);
                            numLegWear = GetNumber(data.legWearsLenght, myConnection, "Her leg wear is: ", "SELECT * FROM LegWear", 9, 9);
                            Console.Clear();

                            //Write Whole Gobling
                            nameString1 = name;
                            hairString1 = GetString("SELECT * FROM Hair WHERE ID = ", myConnection, numHair);
                            earString1 = GetString("SELECT * FROM Ears WHERE ID = ", myConnection, numEar);
                            eyeColorString1 = GetString("SELECT * FROM EyeColor WHERE ID = ", myConnection, numEyeColor);
                            hairColorString1 = GetString("SELECT * FROM HairColor WHERE ID = ", myConnection, numHairColor);
                            skinColorString1 = GetString("SELECT * FROM SkinColor WHERE ID = ", myConnection, numSkinColor);
                            bodyWearString1 = GetString("SELECT * FROM BodyWear WHERE ID = ", myConnection, numBodyWear);
                            headWearString1 = GetString("SELECT * FROM HeadWear WHERE ID = ", myConnection, numHeadWear);
                            legWearString1 = GetString("SELECT * FROM LegWear WHERE ID = ", myConnection, numLegWear);


                            Console.WriteLine("SUMMARY ");
                            Console.WriteLine("Name: " + nameString1);
                            Console.WriteLine("Hair: " + hairString1);
                            Console.WriteLine("Ear: " + earString1);
                            Console.WriteLine("EyeColor: " + eyeColorString1);
                            Console.WriteLine("HairColor: " + hairColorString1);
                            Console.WriteLine("SkinColor: " + skinColorString1);
                            Console.WriteLine("Body Wear: " + bodyWearString1);
                            Console.WriteLine("Head Wear: " + headWearString1);
                            Console.WriteLine("Leg Wear: " + legWearString1);
                            Console.WriteLine("--------------------------------");

                            Console.WriteLine("IS This Goblin OK? Yes = y / Quit = q");

                            string question1;
                            question1 = Console.ReadLine();

                            if (question1 == "y")
                            {
                                //Save charecter 
                                string insertion1 = "INSERT INTO Goblin(ID, GoblinName, HairID, EarsID, HeadWearID, BodyWearID, HairColorID, SkinColorID, EyeColorID, LegWearID) VALUES(@id, @name, @hair, @ear, @headWear, @bodyWear, @hairColor, @skinColor, @eyeColor, @legWear)";

                                SQLiteCommand newCommand1 = new SQLiteCommand(insertion1, myConnection);

                                newCommand1.Parameters.AddWithValue("@id", data.goblings + 1);
                                newCommand1.Parameters.AddWithValue("@name", name);
                                newCommand1.Parameters.AddWithValue("@hair", numHair);
                                newCommand1.Parameters.AddWithValue("@ear", numEar);
                                newCommand1.Parameters.AddWithValue("@headWear", numHeadWear);
                                newCommand1.Parameters.AddWithValue("@hairColor", numHairColor);
                                newCommand1.Parameters.AddWithValue("@bodyWear", numBodyWear);
                                newCommand1.Parameters.AddWithValue("@skinColor", numSkinColor);
                                newCommand1.Parameters.AddWithValue("@eyeColor", numEyeColor);
                                newCommand1.Parameters.AddWithValue("@legWear", numLegWear);

                                var result1 = newCommand1.ExecuteNonQuery();
                                Console.WriteLine("Rows Added : {0}", result1);

                                goblins = FindGoblings(myConnection, FindGoblingsId(myConnection));
                                data = GetAllLenght(myConnection);

                                thruuth = true;
                            }
                            else if (question1 == "q")
                            {
                                break;
                            }
                            else
                            {
                                Console.Clear();
                                thruuth = false;
                            }

                        }
                        break;



                    //Create random goblin
                    case 3:

                        bool isGonaTrue = false;
                        while (!isGonaTrue)
                        {

                            int randname1 = r.Next(1, data.namesLenght);
                            int randnumHair1 = r.Next(1, data.hairsLenght);
                            int randnumEar1 = r.Next(1, data.earsLenght);

                            int randnumEyeColor1 = r.Next(1, data.eyeColorsLenght);
                            int randnumHairColor1 = r.Next(1, data.hairsLenght);
                            int randnumSkinColor1 = r.Next(1, data.skinColorsLenght);

                            int randnumBodyWear1 = r.Next(1, data.bodyWearsLenght);
                            int randnumHeadWear1 = r.Next(1, data.headWearsLenght);
                            int randnumLegWear1 = r.Next(1, data.legWearsLenght);

                            nameString1 = "XXX";
                            hairString1 = "XXX";
                            earString1 = "XXX";
                            eyeColorString1 = "XXX";
                            hairColorString1 = "XXX";
                            skinColorString1 = "XXX";

                            bodyWearString1 = "XXX";
                            headWearString1 = "XXX";
                            legWearString1 = "XXX";

                            nameString1 = GetString("SELECT * FROM Name WHERE ID = ", myConnection, randname1);
                            hairString1 = GetString("SELECT * FROM Hair WHERE ID = ", myConnection, randnumHair1);
                            earString1 = GetString("SELECT * FROM Ears WHERE ID = ", myConnection, randnumEar1);
                            eyeColorString1 = GetString("SELECT * FROM EyeColor WHERE ID = ", myConnection, randnumEyeColor1);
                            hairColorString1 = GetString("SELECT * FROM HairColor WHERE ID = ", myConnection, randnumHairColor1);
                            skinColorString1 = GetString("SELECT * FROM SkinColor WHERE ID = ", myConnection, randnumSkinColor1);
                            bodyWearString1 = GetString("SELECT * FROM BodyWear WHERE ID = ", myConnection, randnumBodyWear1);
                            headWearString1 = GetString("SELECT * FROM HeadWear WHERE ID = ", myConnection, randnumHeadWear1);
                            legWearString1 = GetString("SELECT * FROM LegWear WHERE ID = ", myConnection, randnumLegWear1);


                            Console.Clear();

                            int idd = data.goblings + 1;

                            Console.WriteLine("SUMMARY ");
                            Console.WriteLine("Name: " + nameString1);
                            Console.WriteLine("Hair: " + hairString1);
                            Console.WriteLine("Ear: " + earString1);
                            Console.WriteLine("EyeColor: " + eyeColorString1);
                            Console.WriteLine("HairColor: " + hairColorString1);
                            Console.WriteLine("SkinColor: " + skinColorString1);
                            Console.WriteLine("Body Wear: " + bodyWearString1);
                            Console.WriteLine("Head Wear: " + headWearString1);
                            Console.WriteLine("Leg Wear: " + legWearString1);
                            Console.WriteLine("--------------------------------");

                            Console.WriteLine("IS This Goblin OK? Yes = y / Quit = q");

                            string question2;
                            question2 = Console.ReadLine();


                            if (question2 == "y")
                            {
                                //Save charecter 
                                string insertion2 = "INSERT INTO Goblin(ID, GoblinName, HairID, EarsID, HeadWearID, BodyWearID, HairColorID, SkinColorID, EyeColorID, LegWearID) VALUES(@id, @name, @hair, @ear, @headWear, @bodyWear, @hairColor, @skinColor, @eyeColor, @legWear)";


                                SQLiteCommand newCommand2 = new SQLiteCommand(insertion2, myConnection);

                                newCommand2.Parameters.AddWithValue("@id", data.goblings + 1);
                                newCommand2.Parameters.AddWithValue("@name", nameString1);
                                newCommand2.Parameters.AddWithValue("@hair", randnumHair1);
                                newCommand2.Parameters.AddWithValue("@ear", randnumEar1);
                                newCommand2.Parameters.AddWithValue("@headWear", randnumHeadWear1);
                                newCommand2.Parameters.AddWithValue("@bodyWear", randnumBodyWear1);
                                newCommand2.Parameters.AddWithValue("@hairColor", randnumHairColor1);
                                newCommand2.Parameters.AddWithValue("@skinColor", randnumSkinColor1);
                                newCommand2.Parameters.AddWithValue("@eyeColor", randnumEyeColor1);
                                newCommand2.Parameters.AddWithValue("@legWear", randnumLegWear1);

                                var result1 = newCommand2.ExecuteNonQuery();
                                Console.WriteLine("Rows Added : {0}", result1);

                                goblins = FindGoblings(myConnection, FindGoblingsId(myConnection));
                                data = GetAllLenght(myConnection);

                                Console.Clear();
                                isGonaTrue = true;
                            }
                            else if (question2 == "q")
                            {
                                Console.Clear();
                                break;
                            }
                            else
                            {
                                Console.Clear();
                                isGonaTrue = false;
                            }
                        }


                        break;

                    case 0:
                        Console.Clear();

                        Console.WriteLine("Are you suce you want to quit? (y/n)");
                        string question;
                        question = Console.ReadLine();

                        if (question == "y")
                        {

                            link = true;
                        }
                        else
                        {
                            return;
                        }
                        break;
                }

            }

        }




    }
}